// Copyright © 2017-2020 Trust Wallet.
//
// This file is part of Trust. The full Trust copyright notice, including
// terms governing use, modification, and redistribution, is contained in the
// file LICENSE at the root of the source code distribution tree.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

import Foundation

public final class IoTeXStaking {

    public static func stake(candidate: Data, duration: UInt64, nonDecay: Bool, data: Data) -> Data {
        let candidateData = TWDataCreateWithNSData(candidate)
        defer {
            TWDataDelete(candidateData)
        }
        let dataData = TWDataCreateWithNSData(data)
        defer {
            TWDataDelete(dataData)
        }
        return TWDataNSData(TWIoTeXStakingStake(candidateData, duration, nonDecay, dataData))
    }

    public static func unstake(pyggIndex: UInt64, data: Data) -> Data {
        let dataData = TWDataCreateWithNSData(data)
        defer {
            TWDataDelete(dataData)
        }
        return TWDataNSData(TWIoTeXStakingUnstake(pyggIndex, dataData))
    }

    public static func withdraw(pyggIndex: UInt64, data: Data) -> Data {
        let dataData = TWDataCreateWithNSData(data)
        defer {
            TWDataDelete(dataData)
        }
        return TWDataNSData(TWIoTeXStakingWithdraw(pyggIndex, dataData))
    }

    public static func addStake(pyggIndex: UInt64, data: Data) -> Data {
        let dataData = TWDataCreateWithNSData(data)
        defer {
            TWDataDelete(dataData)
        }
        return TWDataNSData(TWIoTeXStakingAddStake(pyggIndex, dataData))
    }

    public static func moveStake(pyggIndex: UInt64, candidate: Data, data: Data) -> Data {
        let candidateData = TWDataCreateWithNSData(candidate)
        defer {
            TWDataDelete(candidateData)
        }
        let dataData = TWDataCreateWithNSData(data)
        defer {
            TWDataDelete(dataData)
        }
        return TWDataNSData(TWIoTeXStakingMoveStake(pyggIndex, candidateData, dataData))
    }

    let rawValue: OpaquePointer

    init(rawValue: OpaquePointer) {
        self.rawValue = rawValue
    }


}
