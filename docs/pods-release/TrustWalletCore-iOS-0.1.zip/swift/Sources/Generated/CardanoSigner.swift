// Copyright © 2017-2020 Trust Wallet.
//
// This file is part of Trust. The full Trust copyright notice, including
// terms governing use, modification, and redistribution, is contained in the
// file LICENSE at the root of the source code distribution tree.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

import Foundation

public final class CardanoSigner {

    public static func planTransaction(input: TW_Cardano_Proto_SigningInput) -> TW_Cardano_Proto_TransactionPlan {
        let inputData = TWDataCreateWithNSData(try! input.serializedData())
        defer {
            TWDataDelete(inputData)
        }
        let resultData = TWDataNSData(TWCardanoSignerPlanTransaction(inputData))
        return try! TW_Cardano_Proto_TransactionPlan(serializedData: resultData)
    }

    public static func sign(input: TW_Cardano_Proto_SigningInput, plan: TW_Cardano_Proto_TransactionPlan) -> TW_Cardano_Proto_SigningOutput {
        let inputData = TWDataCreateWithNSData(try! input.serializedData())
        defer {
            TWDataDelete(inputData)
        }
        let planData = TWDataCreateWithNSData(try! plan.serializedData())
        defer {
            TWDataDelete(planData)
        }
        let resultData = TWDataNSData(TWCardanoSignerSign(inputData, planData))
        return try! TW_Cardano_Proto_SigningOutput(serializedData: resultData)
    }

    let rawValue: OpaquePointer

    init(rawValue: OpaquePointer) {
        self.rawValue = rawValue
    }


}
