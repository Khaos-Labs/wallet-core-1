// Copyright © 2017-2020 Trust Wallet.
//
// This file is part of Trust. The full Trust copyright notice, including
// terms governing use, modification, and redistribution, is contained in the
// file LICENSE at the root of the source code distribution tree.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

public enum HRP: UInt32, CaseIterable, CustomStringConvertible  {
    case unknown = 0
    case binance = 1
    case bitcoin = 2
    case bitcoinCash = 3
    case bitcoinTestnet = 4
    case cosmos = 5
    case digiByte = 6
    case groestlcoin = 7
    case harmony = 8
    case ioTeX = 9
    case kava = 10
    case litecoin = 11
    case monacoin = 12
    case qtum = 13
    case terra = 14
    case viacoin = 15
    case zilliqa = 16

    public var description: String {
        switch self {
        case .unknown: return ""
        case .binance: return "bnb"
        case .bitcoin: return "bc"
        case .bitcoinCash: return "bitcoincash"
        case .bitcoinTestnet: return "tb"
        case .cosmos: return "cosmos"
        case .digiByte: return "dgb"
        case .groestlcoin: return "grs"
        case .harmony: return "one"
        case .ioTeX: return "io"
        case .kava: return "kava"
        case .litecoin: return "ltc"
        case .monacoin: return "mona"
        case .qtum: return "qc"
        case .terra: return "terra"
        case .viacoin: return "via"
        case .zilliqa: return "zil"
        }
    }
}
