// Copyright © 2017-2020 Trust Wallet.
//
// This file is part of Trust. The full Trust copyright notice, including
// terms governing use, modification, and redistribution, is contained in the
// file LICENSE at the root of the source code distribution tree.

public typealias CardanoTransaction = TW_Cardano_Proto_Transaction;
public typealias CardanoTransactionInput = TW_Cardano_Proto_TransactionInput;
public typealias CardanoOutPoint = TW_Cardano_Proto_OutPoint;
public typealias CardanoTransactionOutput = TW_Cardano_Proto_TransactionOutput;
public typealias CardanoUnspentTransaction = TW_Cardano_Proto_UnspentTransaction;
public typealias CardanoSigningInput = TW_Cardano_Proto_SigningInput;
public typealias CardanoTransactionPlan = TW_Cardano_Proto_TransactionPlan;
public typealias CardanoSigningOutput = TW_Cardano_Proto_SigningOutput;
