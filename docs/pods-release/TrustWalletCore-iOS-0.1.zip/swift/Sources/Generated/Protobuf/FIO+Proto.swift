// Copyright © 2017-2020 Trust Wallet.
//
// This file is part of Trust. The full Trust copyright notice, including
// terms governing use, modification, and redistribution, is contained in the
// file LICENSE at the root of the source code distribution tree.

public typealias FIOPublicAddress = TW_FIO_Proto_PublicAddress;
public typealias FIOAction = TW_FIO_Proto_Action;
public typealias FIOChainParams = TW_FIO_Proto_ChainParams;
public typealias FIOSigningInput = TW_FIO_Proto_SigningInput;
public typealias FIOSigningOutput = TW_FIO_Proto_SigningOutput;
